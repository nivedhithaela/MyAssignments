package week3.day2;

public class WebElement {
	public void click() {
		System.out.println("Click Web Element");
	}
	public void setText(String text) {
		System.out.println(text);
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
