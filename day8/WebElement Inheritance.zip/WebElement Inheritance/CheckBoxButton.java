package week3.day2;

public class CheckBoxButton extends Button {
	public void clickCheckButton() {
		System.out.println("Check Button Clicked");
	}

	public static void main(String[] args) {
		CheckBoxButton cbb=new CheckBoxButton();
		cbb.click();
		cbb.setText("hello");
		cbb.submit();
		cbb.clickCheckButton();

	}

}
