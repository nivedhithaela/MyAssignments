package week3.day2;

public class Elements extends Button {
	

	public static void main(String[] args) {
		Elements ele=new Elements();
		ele.click();
		ele.setText("hello");
		ele.submit();
		
		CheckBoxButton cbo=new CheckBoxButton();
		cbo.click();
		cbo.setText("CheckBox");
		cbo.submit();
		cbo.clickCheckButton();
		
		RadioButton rb=new RadioButton();
		rb.click();
		rb.setText("RadioButton");
		rb.submit();
		rb.selectRadioButton();
		
		TextField tf1=new TextField();
		tf1.click();
		tf1.setText("TF");
		tf1.getText();
		
		WebElement wb=new WebElement();
		wb.click();
		wb.setText("Web Elements");
		
		
		
		

	}

}
