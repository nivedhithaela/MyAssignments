package week3.day2;

public class RadioButton extends Button {
	public void selectRadioButton() {
		System.out.println("Radio Button selected");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
