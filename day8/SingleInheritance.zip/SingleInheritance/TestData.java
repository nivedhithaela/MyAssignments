package week3.day2;

public class TestData {
	public void enterCredentials(){
		System.out.println("Enter Credentials");
		
	}
	public void navigateToHomePage() {
		System.out.println("Navigated to Home Page");
	}

}
