package week3.day2;

public class LoginTestData2 extends TestData {
	public void enterUsername() {
		System.out.println("User2");
	}
	public void enterPassword(){
		System.out.println("Password2");
		
	}

	public static void main(String[] args) {
		LoginTestData2 lt2=new LoginTestData2();
		lt2.enterCredentials();
		lt2.navigateToHomePage();
		lt2.enterUsername();
		lt2.enterPassword();

	}

}
