package week3.day2;

public class LoginTestData1 extends TestData {
	public void enterUsername() {
		System.out.println("User1");
		
	}
	public void enterPassword(){
		System.out.println("Password1");
		
	}

	public static void main(String[] args) {
		LoginTestData1 lt1=new LoginTestData1();
		lt1.enterCredentials();
		lt1.navigateToHomePage();
		lt1.enterUsername();
		lt1.enterPassword();
		
		
		
		

	}

}
