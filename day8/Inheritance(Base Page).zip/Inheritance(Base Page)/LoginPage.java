package week3.day2;

public class LoginPage extends BasePage {
	@Override public void performCommonTask() {
		super.performCommonTask();
		System.out.println("Task");
	}

	public static void main(String[] args) {
		LoginPage lp=new LoginPage();
		lp.performCommonTask();
		lp.enterText();
		

	}

}
