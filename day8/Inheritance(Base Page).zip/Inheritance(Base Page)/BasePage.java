package week3.day2;

public class BasePage {
	public void findElement(){
		System.out.println("Finding Element");
	}
	public void clickElement() {
		System.out.println("Click");
	}
	public void enterText() {
		System.out.println("Text");
	}
	public void performCommonTask() {
		System.out.println("Common");
	}
	
	

	public static void main(String[] args) {
		BasePage bp=new BasePage();
		bp.performCommonTask();
		

	}

}
