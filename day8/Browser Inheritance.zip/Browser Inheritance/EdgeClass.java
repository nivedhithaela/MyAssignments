package week3.day2;

public class EdgeClass extends ChromeClass {
	public void takeSnap() {
		System.out.println("Take Snap");
	}
	public void clearCookies() {
		System.out.println("Cookies cleared");
	}

	public static void main(String[] args) {
		EdgeClass ec=new EdgeClass();
		ec.browserName="Edge";
		ec.browserVersion=120.0f;
		System.out.println(ec.browserName);
		System.out.println(ec.browserVersion);
		ec.openURL();
		ec.closeBrowser();
		ec.navigateBack();
		ec.openIncognito();
		ec.clearCache();
		ec.takeSnap();
		ec.clearCookies();

	}

}
