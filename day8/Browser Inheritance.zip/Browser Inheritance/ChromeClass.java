package week3.day2;

public class ChromeClass extends Browser  {
	public void openIncognito() {
		System.out.println("Incognito opened");
	}
	public void clearCache() {
		System.out.println("Cache cleared");
	}

	public static void main(String[] args) {
		ChromeClass cc=new ChromeClass();
		cc.browserName="Chrome";
		cc.browserVersion=132.0f;
		System.out.println(cc.browserName);
		System.out.println(cc.browserVersion);
		cc.openURL();
		cc.closeBrowser();
		cc.navigateBack();
		cc.openIncognito();
		cc.clearCache();
		

	}

}
