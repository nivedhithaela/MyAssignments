package week3.day2;

public class Browser {
	String browserName;
	float browserVersion;
	public void openURL() {
		System.out.println("URL Opened");
	}
	public void closeBrowser() {
		System.out.println("Browser closed");
	}
	public void navigateBack() {
		System.out.println("Navigated Back");
	}
	
	

}
