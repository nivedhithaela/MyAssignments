package week3.day2;

public class SafariClass extends EdgeClass{
	public void readerMode() {
		System.out.println("Reader mode");
	}
	public void fullScreenMode() {
		System.out.println("Full Screen Mode");
	}

	public static void main(String[] args) {
		SafariClass sc=new SafariClass();
		sc.browserName="Safari";
		sc.browserVersion=140.0f;
		System.out.println(sc.browserName);
		System.out.println(sc.browserVersion);
		sc.openURL();
		sc.closeBrowser();
		sc.navigateBack();
		sc.openIncognito();
		sc.clearCache();
		sc.takeSnap();
		sc.clearCookies();
		sc.readerMode();
		sc.fullScreenMode();
		
		

	}

}
