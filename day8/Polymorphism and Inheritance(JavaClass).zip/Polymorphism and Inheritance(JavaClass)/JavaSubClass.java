package week3.day2;

public class JavaSubClass extends JavaClass {
	@Override public void takeSnap() {
		super.takeSnap();
		System.out.println("Snap Overridden");
		
	}

	public static void main(String[] args) {
		JavaSubClass jco=new JavaSubClass();
		jco.takeSnap();
		jco.reportStep("hi", "202");

	}

}
