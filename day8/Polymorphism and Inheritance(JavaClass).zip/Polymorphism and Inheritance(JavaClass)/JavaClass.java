package week3.day2;

public class JavaClass {
	public void reportStep(String msg,String status) {
		System.out.println(msg+" "+status);
	}
    public void reportStep(String msg,String status,boolean snap) {
    	System.out.println(msg+" "+" "+status+" "+snap);
		
	}
    public void takeSnap() {
    	System.out.println("Snap Taken");
    }
	

	public static void main(String[] args) {
		JavaClass jc=new JavaClass();
	    jc.reportStep("hi", "true");
		jc.reportStep("hello", "false", true);
		jc.takeSnap();
		
	

	}

}
