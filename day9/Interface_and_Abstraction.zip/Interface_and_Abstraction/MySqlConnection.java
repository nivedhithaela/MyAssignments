package week3.day3;

public abstract class MySqlConnection implements DatabaseConnection {
	public void executeQuery() {
		System.out.println("Execute Query");
	}

}
